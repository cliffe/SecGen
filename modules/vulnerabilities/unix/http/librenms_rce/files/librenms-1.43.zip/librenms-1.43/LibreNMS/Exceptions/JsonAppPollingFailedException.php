<?php

namespace LibreNMS\Exceptions;

class JsonAppPollingFailedException extends JsonAppException
{

}
