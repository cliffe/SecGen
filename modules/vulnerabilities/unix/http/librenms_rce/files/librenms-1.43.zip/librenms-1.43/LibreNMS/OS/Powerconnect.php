<?php
/**
 * Powerconnect.php
 *
 * Dell PowerConnect
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @package    LibreNMS
 * @link       http://librenms.org
 * @copyright  2018 Tony Murray
 * @author     Tony Murray <murraytony@gmail.com>
 */

namespace LibreNMS\OS;

use LibreNMS\Device\Processor;
use LibreNMS\Interfaces\Discovery\ProcessorDiscovery;
use LibreNMS\Interfaces\Polling\ProcessorPolling;
use LibreNMS\OS;
use LibreNMS\OS\Traits\VxworksProcessorUsage;

class Powerconnect extends OS implements ProcessorDiscovery, ProcessorPolling
{
    // pull in VxWorks processor parsing, but allow us to extend it
    use VxworksProcessorUsage {
        VxworksProcessorUsage::discoverProcessors as discoverVxworksProcessors;
        VxworksProcessorUsage::pollProcessors as pollVxworksProcessors;
    }

    /**
     * Discover processors.
     * Returns an array of LibreNMS\Device\Processor objects that have been discovered
     *
     * @return array Processors
     */
    public function discoverProcessors()
    {
        $device = $this->getDevice();

        if (starts_with($device['sysObjectID'], '.1.3.6.1.4.1.674.10895.3031')) {
            d_echo("Dell Powerconnect 55xx");
            return array(
                Processor::discover(
                    'powerconnect-nv',
                    $this->getDeviceId(),
                    '.1.3.6.1.4.1.89.1.7.0',
                    0
                )
            );
        } elseif (starts_with($device['sysObjectID'], ['.1.3.6.1.4.1.674.10895.3024', '.1.3.6.1.4.1.674.10895.3065'])) {
            return $this->discoverVxworksProcessors('.1.3.6.1.4.1.674.10895.5000.2.6132.1.1.1.1.4.9.0');
        }

        return $this->discoverVxworksProcessors('.1.3.6.1.4.1.674.10895.5000.2.6132.1.1.1.1.4.4.0');
    }

    /**
     * Poll processor data.  This can be implemented if custom polling is needed.
     *
     * @param array $processors Array of processor entries from the database that need to be polled
     * @return array of polled data
     */
    public function pollProcessors(array $processors)
    {
        $data = array();

        foreach ($processors as $processor) {
            if ($processor['processor_type'] == 'powerconnect-nv') {
                $data[$processor['processor_id']] = snmp_get($this->getDevice(), $processor['processor_oid'], '-Oqv');
            } else {
                $data += $this->pollVxworksProcessors(array($processor));
            }
        }

        return $data;
    }
}
