source: Extensions/Alerting.md
<meta http-equiv="refresh" content="0; url=/Alerting/Alerting/" />
