<meta http-equiv="refresh" content="0; url=/Extensions/metrics/Prometheus/" />
