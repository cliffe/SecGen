source: General/Contributing.md
<meta http-equiv="refresh" content="0; url=/Developing/" />
