source: Installation/Installation-(RHEL-CentOS).md
<meta http-equiv="refresh" content="0; url=/Installation/Installation-CentOS-7-Apache/" />
