<h2>Links</h2>
<ul>
	<li><a href="http://nanocms.in/">NanoCMS Website</a></li>
	<li><a href="http://nanocms.in/blog">Latest News / Blog</a></li>
	<li><a href="http://nanocms.in/templates">NanoCMS Templates</a></li>
	<li><a href="http://nanocms.in/docs">Documentation</a></li>
	<li><a href="http://nanocms.in/forums">Forums & Discussion</a></li>
</ul>

<h2>Login</h2>
<a href="./data/nanoadmin.php">Admin Login</a>