<h2>Contact</h2>
<p>You can contact Kalyan ( <a href='http://KalyanChakravarthy.net'>Website</a>, <a href='mailto:kalyan@KalyanChakravarthy.net'>Email</a> ) for feedback, bug reports, tips, feature-requests etc., etc.</p>
<p>Or even better you can post it on NanoCMS Forums ( <a href='http://nanocms.in/forums'> http://nanocms.in/forums</a> )</p>