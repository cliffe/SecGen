<h2>How to install NanoCMS</h2>
<ul>
  <li>Nothing to see here ;)</li>
</ul>