<h2>License : GNU/GPL</h2>
<p>The software NanoCMS v0.40 is released under GNU/GPL License. ( Included in the download version ).</p>
<h2>Support NanoCMS</h2>
<p>If you use this software it would be appreciated if you can support us by
	<ul>
		<li>Linking back</li>
		<li>Spreading about NanoCMS</li>
		<li>Contributing documentation ( http://nanocms.in/docs )</li>
		<li>Helping others on forums ( http://nanocms.in/forums )</li>
		<li>Monetary donation</li>
	</ul>
</p>
