<?php
/*
 * @package Include/help/es
 */
?>

<h1>Alerta correlaci&oacute;n</h1>

<p>Permite usar m&aacute;s de un m&oacute;dulo para generar una reacci&oacute;n en <?php echo get_product_name(); ?>. Dichos m&oacute;dulos pueden pertenecer a un mismo agente o a varios.</p>

