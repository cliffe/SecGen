<?php
/**
 * @package Include/help/es
 */
?>
<h1>Descripción de campos</h1>

Es posible configurar una descripcion personalizada a cada campo en la configuración del comando.
<br><br>
Esta descripción aparecerá en el formulario de configuración de la acción junto a la caja de texto del campo cuando se seleccione el comando.
