<?php
/**
 * @package Include/help/es
 */
?>
<h1>Categorías en <?php echo get_product_name(); ?></h1>

Se pueden configurar unas categorias en el sistema, se asignan a los módulos que se quiera. <br>
El único usuario que tiene permisos para realizar la creación y configuración de categorias es el administrador y se pueden utilizar para la tarificación de modulos dependiendo de la categoría a la que pertenezcan.

