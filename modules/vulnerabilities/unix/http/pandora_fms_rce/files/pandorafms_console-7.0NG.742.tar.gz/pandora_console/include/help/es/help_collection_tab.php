<?php
/*
    Include Package help/es
*/
?>

<h1>Colecciones del agente</h1>

<p>Una colección es un grupo de ficheros (ejecutables o scripts) que son copiados a la maquina del agente en un diretorio específico. Con esto se puede transferir remotamente software a la máquina del agente de una manera sencilla.</p>

