<?php
/**
 * @package Include/help/en
 */
?>
<h1>Macros de módulos</h1>

<p>
Las siguientes macros están disponibles:
</p>
<ul>
<li>_agentcustomfield_<i>n</i>_: Campo personalizado número <i>n</i> del agente (eg. _agentcustomfield_9_). </li>
</ul>
