<?php
/*
 * @package Include/help/es
 */
?>

<h1>Grupos de componentes</h1>

<p>Un componente es un módulo genérico que puede aplicarse a agentes de forma repetida como si fuera una plantilla. Con esta vista puedes crear grupos para estos componentes.</p>

