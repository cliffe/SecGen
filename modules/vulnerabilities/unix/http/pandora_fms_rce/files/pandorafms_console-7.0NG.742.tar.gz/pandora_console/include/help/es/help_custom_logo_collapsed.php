<?php
/**
 * @package Include/help/es
 */
?>
<h1> Logo (Marca de empresa)</h1>

Esta opción sirve para poder subir su propio logo, que estará visible en el menú de <?php echo get_product_name(); ?>. Este logo será visible cuando el menú esté plegado.
<br><br>
La imagen debe tener el formato PNG y un tamaño de 60x60 pixeles.
<br><br>
Debe subir su logo al directorio /images/custom_logo.
