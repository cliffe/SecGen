<?php
/*
 * @package Include/help/es/
 */
?>

<h1>Alertas externas</h1>

<p>Las Alertas Externas son similares a las Alertas, la diferencia es que estas permiten enlazar alertas con módulos de agentes que no están en la lista principal de módulos de la política. Es muy útil para asignar alertas sólo a algunos módulos de agente y no a todos ellos.</p> 

