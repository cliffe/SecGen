<?php
/*
    Package Include/help/en
*/
?>
<h1>Agent GIS view</h1>

<p>
Esta vista permite a los usuarios ver la informacion GIS del agente de una manera grafica.
</p>

<p>
Con GIS se puede ver la informacion posicional del agente dentro de mapas interactivos. Ademas, es posible actualizar la informacion posicional del agente (longitud, latitud, altitud).
</p>

