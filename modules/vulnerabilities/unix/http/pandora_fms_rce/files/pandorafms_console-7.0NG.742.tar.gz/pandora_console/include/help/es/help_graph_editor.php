<?php
/*
 * @package Include/help/es/
 */
?>

<h1>Editor de items</h1>

<p>Esta vista permite a&ntile;ade módulos a gráficos. Puedes a&ntilde;adir más de un módulo para crear gráficos combinados. Los gráficos combinados permiten definir el peso de las variables, tendrán valores de diferentes módulos que serán de uno a mas agentes. De esta forma se puede comparar visualmente información que venga de diferentes fuentes.</p>

