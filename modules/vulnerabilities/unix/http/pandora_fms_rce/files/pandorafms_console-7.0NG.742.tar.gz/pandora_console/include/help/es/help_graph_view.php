<?php
/*
 * @package Include/help/es/
 */
?>

<h1>Vista de graficas</h1>

<p>En esta vista se muestra la visualizacion de gráficas. Se puede filtrar por fecha, periodo y el factor de zoom.</p>
