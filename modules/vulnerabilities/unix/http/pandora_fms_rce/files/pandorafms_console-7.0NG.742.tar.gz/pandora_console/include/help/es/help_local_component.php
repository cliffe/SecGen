<?php
/*
 * @package Include/help/en
 */
?>

<h1>Componente local</h1>

<p>Los componentes locales son elementos que pueden aplicarse a agentes como plantillas. Con la versión Enterprise, esto se puede automatizar y aplicar de forma remota con las políticas.</p>
