<?php
/*
 * @package Include/help/es/
 */
?>

<h1>Modulos linkados</h1>

<p>Los modulos no enlazados son modulos que no seran modificados por las politicas en un futuro. Esto es muy util porque permite definir excepciones al comportamiento de la politica. No se necesita eliminar un agente para cambiar el comportamiento de un modulo (por ejemplo, min_threshold), solo no enlazarlo a la politica.</p>
