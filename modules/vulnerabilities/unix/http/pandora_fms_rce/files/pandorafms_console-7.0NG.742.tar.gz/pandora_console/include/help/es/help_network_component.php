<?php
/**
 * @package Include/help/es
 */
?>
<h1>Componente de red</h1>

<p>
La caja de selección del componente de red le permite seleccionar una plantilla de una lista de más de cien, y rellenar automáticamente algunos campos con los valores típicos.
</p>
<p>
Para ello, seleccione la plantilla que quiere, pulse en «Obtener datos» y espere unos segundos hasta que se rellene la información. Dependiendo de la plantilla, algunos campos se rellenarán y otros no, por ejemplo:
</p>
<ul>
    <li>«Puerto TCP» se rellenará para «Check FTP Server» pero «SNMP OID» no</li>
    <li>«Puerto TCP» no se rellenará para «Catalyst CPU Usage (5min)» pero sí lo hará «SNMP OID».</li>
</ul>
