<?php
/**
 * @package Include/help/en
 */
?>
<h1>Mapa de red</h1>
<p>Esta es la sección de Mapas de red.</p>

<p>Para salvar un mapa creado, debes aplicar los cambios primero.</p>

<p>Para construir un submapa, debes hacer click en los bordes.</p>
