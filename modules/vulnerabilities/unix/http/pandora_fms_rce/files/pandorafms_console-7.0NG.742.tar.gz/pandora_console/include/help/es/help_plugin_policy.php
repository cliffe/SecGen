<?php
/*
 * @package Include/help/es/
 */
?>

<h1>Plugins de agente</h1>

<p>Con el editor de plugins en políticas se pueden propagar los plugins de agentes con facilidad.
<br><br>
Se pueden añadir plugins de agente en una política para que se creen en cada agente local al ser aplicada. 
<br><br>
Ejemplo: cscript.exe //B "%ProgramFiles%\Pandora_Agent\util\df.vbs" 

