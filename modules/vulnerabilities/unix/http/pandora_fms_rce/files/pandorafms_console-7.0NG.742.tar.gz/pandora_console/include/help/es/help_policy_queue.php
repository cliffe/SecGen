<?php
/*
 * @packafe Include/help/es/
 */
?>

<h1>Cola</h1>

<p>Las diferentes acciones que se pueden realizar no se aplicarán hasta que la política se aplique. Si agregamos a la política un agente podemos crear diversos módulos y alertas, por ejemplo, pero hasta que no apliquemos la política no se harán efectivos.</p>
~                     
