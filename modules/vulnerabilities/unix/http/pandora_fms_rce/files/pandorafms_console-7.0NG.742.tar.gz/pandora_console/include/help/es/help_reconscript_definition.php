<?php
/**
 * @package Include/help/es
 */
?>
<h1>Definicion de recon script</h1>

<p>Los "ReconScripts" permiten trabajar con cosas mucho mas flexibles. Los scripts recon son desarrollados individualmente para objetivos especificos, como plugins de red o otros plugins de agentes. cada ReconScript es diferentes a la vez que sus propositos.</p> 

<p>La idea basica es "detectar" cosas en el sistema que reconoce y automaticamente trazarlo en un monitor (red, plugin o wmi) asi de una manera customizada podremos trazar en una base de datos Oracle, un nuevo host virtual en VmWare gestionado con VirtualCenter o se puede detectar nuevas peticiones en un servidor de aplicaciones WebLogic. Es posible hacer un script o aplicacion que haga las tareas que queremos hacer y planificarlas a traves del servidor Recon.</p>

<p>Un campo con importancia es:</p>

<p><b>Ruta completa al Script:</b> Ruta al script ejecutable.</p>
