<?php
/**
 * @package Include/help/en
 */
?>
<h1>Opciones avanzadas</h1>
<p>
Puede usar una macro en la portada, la cabecera y el pie de pagina:<br><br>
<b>(_DATETIME_)</b>  este token será reemplazado por la fecha y hora actual en el momento de generar el PDF.
<b>(_REPORT_NAME_)</b> este token será reemplazado por el nombre del informe.
<br><br>
Si tiene problemas visualizando una imagen, prueba a usar el formato PNG en vez de usar otros formatos.
</p>
