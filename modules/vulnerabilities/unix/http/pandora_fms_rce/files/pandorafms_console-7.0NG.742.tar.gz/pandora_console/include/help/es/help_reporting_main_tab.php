<?php
/**
 * @package Include/help/en
 */
?>
<h1>Creador de informes</h1>

Para crear un informe, primero debe llenar el formulario proporcionando:
<ul>
    <li>Un nombre</li>
    <li>Un grupo</li>
    <li>Una descripción</li>
</ul>
Luego se debe presionar el boton con el texto Crear.
<br /><br />
Para editar las propiedades de un informe existente sólo cambia el campo de formulario y pulse el boton Actualizar.
