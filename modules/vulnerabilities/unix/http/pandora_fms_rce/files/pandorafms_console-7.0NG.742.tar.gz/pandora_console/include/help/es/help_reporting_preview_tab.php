<?php
/*
 * @package Include/help/es/
 */
?>

<h1>Preview</h1>

<p>Esta pesta&ntilde;a muestra el informe tal como se cuando se genera en formato Html, para poder ir viendo los resultados de una forma cómoda. El informe se ve tal cual lo vería un usuario en la seccion de ver informe. </p>

