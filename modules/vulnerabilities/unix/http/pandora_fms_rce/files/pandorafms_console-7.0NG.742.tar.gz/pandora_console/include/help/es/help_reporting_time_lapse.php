<?php
/**
 * @package Include/help/en
 */
?>
<h1>Reports - Time lapse</h1>
<br>
Este es el lapso de tiempo que refleja el informe. Si es una semana, por ejemplo, el informe mostrará los datos desde hace una semana hasta ahora
