<?php
/*
 * @package Include/help/es
 */
?>

<h1>Wizard SLA</h1>

<p>Permite medir el nivel del servicio (Service Level Agreement) de todos los moduloes de <?php echo get_product_name(); ?>. En es este wizard puedes crear un informe SLA de muchas agentes.</p>

