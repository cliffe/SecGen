<?php
/*
 * @package Include/help/es
 */
?>

<h1>Wizard</h1>

<p>Esta pestaña pertenece a la versión Enterprise de <?php echo get_product_name(); ?>. Esta pestaña nos permite realizar de una forma automática con unos pocos click, y de una vez multitud de items para un informe, con configuraciones comunes pero aplicadas a multitud de agentes y o módulos.</p>
