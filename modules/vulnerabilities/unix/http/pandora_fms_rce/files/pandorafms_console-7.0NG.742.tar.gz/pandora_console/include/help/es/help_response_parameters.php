<?php
/*
 * @package Include/help/es/
 */
?>
<h1>Par&aacute;metros de respuestas de eventos</h1>

<p>Los par&aacute;metros de respuesta van separados por comas.
<br><br>
Por ejemplo:
<br><br>
<i>User,Password,Port</i>
<br><br>
Cada par&aacute;metro puede ser usado como una macro en el comando/URL a&ntilde;adiendo antes y despu&eacute;s un gui&oacute:n bajo.
<br><br>
Por ejemplo:
<br><br>
<i>_Port_</i>
<br><br>
Por favor, no use espacios en blanco en los par&aacute;metros
</p>
