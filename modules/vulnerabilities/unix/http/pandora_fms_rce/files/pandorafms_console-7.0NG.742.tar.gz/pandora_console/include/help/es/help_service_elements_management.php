<?php
/**
 * @package Include/help/es
 */
?>
<h1>Gestión de elementos de servicio</h1>

<p>Esta vista muestra los módulos dentro del servicio actual.</p>

