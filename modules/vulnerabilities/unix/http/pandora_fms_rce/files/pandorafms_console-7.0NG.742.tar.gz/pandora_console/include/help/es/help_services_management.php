<?php
/**
 * @package Include/help/es
 */
?>
<h1>Gestion de servicios</h1>

<p>Esta vista muestra todos los servicios disponibles para ser administrados. También muestra los valores de estado critico, aviso, grupo, etc. de los servicios.</p>

