<?php
/**
 * @package Include/help/en
 */
?>
<h1>Configuracion de conexiones GIS</h1>

<p>
En esta sección, es donde el administrador puede configurar <strong>una conexión a un servidor de mapas GIS</strong>.
</p>
<p>
Puede ver aqui la lista de las conexiones configuradas, y editar cualquier valor de ellas haciendo click sobre su nombre. También puede borrar cualquier conexión o crear nuevas conexiones.
</p>
