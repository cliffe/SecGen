<?php
/*
 * @package Include /help/en
 */
?>

<h1>Custom Value/OID</h1>

<p>Campos personalizados enviados en el trap. Pueden ser datos muy complejos, que tengan una lógica específica en función del dispositivo que envía el trap. Un trap puede enviar varios datos en este campo.</p>
