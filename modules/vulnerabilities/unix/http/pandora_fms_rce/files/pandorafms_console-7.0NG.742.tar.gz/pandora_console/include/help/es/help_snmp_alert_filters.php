<?php
/*
 * @package Include /help/es
 */
?>

<h1>Alert filters</h1>

<p>Estas son las condiciones necesarias para que se dispare la alerta SNMP. Todas las condiciones tienen que satisfacerse para que la alarma SNMP se dispare.</p>
