<?php
/**
 * @package Include/help/es
 */
?>
<h1>Comunidad SNMP</h1>

Comunidad necesaria para monitorizar un OID SNMP.
