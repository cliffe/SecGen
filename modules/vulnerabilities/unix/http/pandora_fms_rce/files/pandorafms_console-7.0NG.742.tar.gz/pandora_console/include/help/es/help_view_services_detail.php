<?php
/*
    Include Package help/es/
*/
?>

<h1>Vista de detalle de servicio</h1>

<p>
Esta vista muestra parametros generales del servicio como los valores de estado critico o aviso y el estado de este. Tambien se muestra un lista completa de los modulos del agente.
</p>

