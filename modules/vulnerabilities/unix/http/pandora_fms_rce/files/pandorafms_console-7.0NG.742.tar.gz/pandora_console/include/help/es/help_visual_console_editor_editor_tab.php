<?php
/*
 * @package Include/help/es
 */
?>

<h1>Editor</h1>

<p>Esta pestaña contiene la mayor parte de la funcionalidad del editor de la consola visual, porque es donde podrás crear los elementos, editarlos y posicionarlos. Es una página dinámica, por lo que es necesario que tu navegador soporte correctamente el lenguaje javascript. Como se puede ver en la captura de pantalla, la pantalla se divide en dos áreas claramente diferenciadas: la caja de botones, el área de trabajo (donde "pintarás" la consola visual) y la paleta de opciones (no visible en esta captura de pantalla).</p>
