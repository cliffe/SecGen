<?php
/*
 * @package Include/help/es/
 */
?>

<h1>List of elements</h1>

<p>Esta pestaña proporciona un formulario tabulado en filas de los elementos que contiene la consola visual que está editando. Es una forma rápida de editar los distintos elementos, además de ser una útil herramienta para los usuarios que necesitan afinar en ciertos valores de los elementos.</p>
