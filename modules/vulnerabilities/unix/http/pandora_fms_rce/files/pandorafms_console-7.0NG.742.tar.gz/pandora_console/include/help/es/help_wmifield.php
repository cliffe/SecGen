<?php
/**
 * @package Include/help/es
 */
?>
<h1>Campo número</h1>

Número de columna que obtener desde el resultado de la consulta WQL (empezando desde cero).
