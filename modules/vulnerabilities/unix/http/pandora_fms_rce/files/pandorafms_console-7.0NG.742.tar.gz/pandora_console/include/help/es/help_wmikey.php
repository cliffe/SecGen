<?php
/**
 * @package Include/help/es
 */
?>
<h1>Texto clave</h1>

Opcional. Subcadena en la buscar el resultado de la consulta WQL. El módulo devuelve 1 si se encuentra, de lo contrario devuelve 0.
