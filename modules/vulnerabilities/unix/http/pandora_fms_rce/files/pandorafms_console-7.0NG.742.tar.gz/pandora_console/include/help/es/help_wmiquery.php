<?php
/**
 * @package Include/help/es
 */
?>
<h1>Consulta WMI</h1>

Cualquier consulta WQL válida. Según Microsot, el lenguaje de consultas WMI (WQL) es un subconjunto del estándar ANSI SQL (American National Standards Institute Structured Query Language), con mínimos cambios semánticos para soportar WMI.
<br /><br />
Ejemplo: SELECT LoadPercentage from Win32_Processor WHERE DeviceID = "CPU0"
