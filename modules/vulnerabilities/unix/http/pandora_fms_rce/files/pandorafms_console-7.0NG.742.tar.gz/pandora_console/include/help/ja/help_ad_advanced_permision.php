<?php
/**
 * @package Include/help/ja
 */
?>
<h1>拡張パーミッション</h1>

<br><br>

<table width="750px" style="display:inline">
<tr>
    <td class=""> 新たなパーミッションを追加する場合、次のようにテキストを追加する必要があります。
        <nav>
        </nav>
        "プロファイルの名前, グループの名前, [グループ AD n1 の名前|グループ AD n2 の名前|
        <nav>
        </nav>
        グループ AD n3 の名前|...],[名前タグ1|名前タグ2|名前タグN|...]"
        <nav>
        </nav>
        グループとタグの間は、上記の例のように "|" で区切る必要があります。
    </td>
</table>
