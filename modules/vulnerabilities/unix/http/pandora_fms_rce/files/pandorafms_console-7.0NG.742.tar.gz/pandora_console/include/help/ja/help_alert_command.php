<?php
/*
 * @package Include/help/ja
 */
?>

<h1>アラートコマンド</h1>

<p>&#34;しきい値を越えた場合&#34;の <?php echo get_product_name(); ?> の動作には、syslog への記録、e-mail、SMS 送信や、<?php echo get_product_name(); ?> が動作するマシンでの任意のスクリプトの実行など、さまざまな種類があります。</p>
