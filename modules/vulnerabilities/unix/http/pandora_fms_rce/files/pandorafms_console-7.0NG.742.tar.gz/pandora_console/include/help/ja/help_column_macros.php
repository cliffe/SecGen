<?php
/**
 * @package Include/help/ja
 */
?>
<h1>モジュールマクロ</h1>

<p>
次のマクロが利用できます:
</p>
<ul>
<li>_agentcustomfield_<i>n</i>_ : エージェントカスタムフィールド番号<i>n</i> (例: _agentcustomfield_9_). </li>
</ul>
<p>
</p>
