<?php
/**
 * @package Include/help/ja
 */
?>
<h1>カスタムロゴ</h1>

This option allows uploading your own logo, which will be visible in the <?php echo get_product_name(); ?> menu. This logo will be visible when the menu is collapsed.
<br><br>
The image must have PNG format and a size of 60x60 pixels.
<br><br>
You must upload your logo to the /images/custom_logo directory.

