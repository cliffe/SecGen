<?php
/**
 * @package Include/help/ja
 */
?>
<h1>対象エージェント</h1>

監視サーバ側から設定可能なエージェントのみ表示されます。
