<?php
/**
 * @package Include/help/ja
 */
?>
<h1>Integria URL</h1>

<p>
Integria の URL は、インストール先のトップページのパスである必要があります。
<br><br>
例: http://192.169.75.4/integria
</p>
