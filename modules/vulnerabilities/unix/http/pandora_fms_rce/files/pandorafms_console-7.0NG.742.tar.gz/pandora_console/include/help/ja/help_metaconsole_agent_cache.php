<?php
/*
    Include package help/ja
*/
?>

<p>For the metaconsole agent cache to work, Make sure <b>Metaconsole DB host</b>, <b>Metaconsole DB name</b>, <b>Metaconsole DB user</b>, <b>Metaconsole DB password</b> and <b>Metaconsole DB port</b> are properly configured.</p>
