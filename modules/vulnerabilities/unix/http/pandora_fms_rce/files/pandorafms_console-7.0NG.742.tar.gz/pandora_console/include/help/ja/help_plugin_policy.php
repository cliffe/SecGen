<?php
/*
 * @package Include/help/ja/
 */
?>

<h1>エージェントプラグイン</h1>

<p>ポリシーのプラグインエディタで、エージェントのプラグインを簡単に展開することができます。
<br><br>
ポリシーを適用したときに、ローカルエージェントにエージェントプラグイン作成するようポリシーに追加することができます。
<br><br>
例: cscript.exe //B "%ProgramFiles%\Pandora_Agent\util\df.vbs" 
