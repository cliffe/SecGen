<h1>予想グラフ</h1>


<?php html_print_image('images/help/projection_periods.png', false, ['height' => '210']); ?>
<br>
<p>
予想グラフは将来のモジュールデータを予想します。予想は線形回帰を利用しています。
</p>
<p>
重要なパラメータは次の通りです。
</p>
<p>
<b>間隔(Period)</b>: 予想に使うデータの時間間隔
</p>
<p>
<b>予想間隔(Projection period)</b>: モジュールデータを予想する将来の時間間隔
</p>
