<?php
/*
 * @package Include/help/ja
 */
?>

<h1>SLA ウィザード</h1>

<p><?php echo get_product_name(); ?> でモニタリングしているサービスレベル (Service Level Agreement) を計測できます。このウィザードでは、複数のエージェントの SLA レポートを作成することができます。</p>
