<?php
/**
 * @package Include/help/ja
 */
?>
<h1>サービスエレメント管理</h1>

<p>現在のサービスにおけるモジュールを表示します。</p>
