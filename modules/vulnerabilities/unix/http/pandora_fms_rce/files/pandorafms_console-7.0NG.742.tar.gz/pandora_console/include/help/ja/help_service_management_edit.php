<?php
/*
 * @package Include help/ja/
 */
?>

<h1>サービスの編集</h1>

<p>サービスを編集するための設定フォームを表示します。</p>
