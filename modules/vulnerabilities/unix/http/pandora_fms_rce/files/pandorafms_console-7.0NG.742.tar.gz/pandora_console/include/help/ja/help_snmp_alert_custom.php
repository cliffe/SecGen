<?php
/*
 * @package Include /help/ja
 */
?>

<h1>全体マッチング</h1>

<p>トラップの&#34;Value&#34;フィールドおよび、&#34;Custom OID&#34;、&#34;Custom Value&#34; フィールド内の検索は、残りのトラップフィールドで行います。</p>
