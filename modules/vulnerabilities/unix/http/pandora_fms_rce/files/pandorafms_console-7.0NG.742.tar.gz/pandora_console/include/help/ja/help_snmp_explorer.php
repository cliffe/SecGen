<?php
/*
    Package Include/help/ja
*/
?>
<h1>SNMPエクスプローラ</h1>

<p>
SNMPエクスプローラは、簡単に snmpwalk をできるようにするための拡張です。snmpwalk は、ターゲットマシンの情報を取得するために、<i>getnexts</i> コマンドを実行します。
</p>
