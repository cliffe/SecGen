<?php
/**
 * @package Include/help/ja
 */
?>
<h1>SNMP コミュニティ</h1>

SNMP OID をモニタするときの SNMP コミュニティ名です。
