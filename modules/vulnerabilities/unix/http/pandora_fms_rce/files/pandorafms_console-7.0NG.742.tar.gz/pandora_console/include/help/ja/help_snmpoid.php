<?php
/**
 * @package Include/help/ja
 */
?>
<h1>SNMP OID</h1>

<?php echo get_product_name(); ?> ネットワークサーバにて MIB の名前解決が可能の場合は、その名前で表示されます。(例: SNMPv2-MIB::sysDescr.0)
MIB が無ければ、数字で表示されます。(例:3.1.3.1.3.5.12.4.0.1)
