<?php
/**
 * @package Include/help/ja
 */
?>
<h1>snmpwalk</h1>

<?php echo get_product_name(); ?> は、簡易 SNMP ブラウザがあり、リモートノードに対して snmpwalk を実行することができます。
<br /><br />
snmpwalk は全 MIB データを取得しますが、その中から一つを選択できます。
また、OID を数値で入力したり、<?php echo get_product_name(); ?> ネットワークサーバに MIB がインストールされていれば、名称で入力することも可能です。
