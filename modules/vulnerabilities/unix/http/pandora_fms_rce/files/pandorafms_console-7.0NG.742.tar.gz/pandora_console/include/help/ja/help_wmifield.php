<?php
/**
 * @package Include/help/ja
 */
?>
<h1>フィールド番号</h1>

WQL クエリ結果のカラム番号です。(0 から始まる)
