<?php
/**
 * @package Include/help/ja
 */
?>
<h1>名前空間</h1>

WMI の名前空間です。使わない場合は設定しないでください。
