<?php
/**
 * @package Include/help/ja
 */
?>
<h1>WMI クエリ</h1>

<p>
WMI クエリ言語(WQL)は、マイクロソフトにより WMI サポートを追加された ANSI SQL のサブセットです。
</p>
<p>
例: SELECT LoadPercentage from Win32_Processor WHERE DeviceID = "CPU0"
</p>
