<?php
/**
 * This redirects to the site's root to prevent directory browsing.
 *  
 * @ignore 
 * @package TikiWiki
 * @subpackage dump
 * @copyright (c) Copyright 2002-2015 by authors of the Tiki Wiki CMS Groupware Project
 * @licence Licensed under the GNU LESSER GENERAL PUBLIC LICENSE. See license.txt for details.
 */
// $Id: index.php 53808 2015-02-06 00:57:47Z jyhem $

// This redirects to the sites root to prevent directory browsing
header("location: ../tiki-index.php");
die;
