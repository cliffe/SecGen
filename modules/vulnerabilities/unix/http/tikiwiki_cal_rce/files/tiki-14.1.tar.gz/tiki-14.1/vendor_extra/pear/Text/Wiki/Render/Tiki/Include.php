<?php
class Text_Wiki_Render_Tiki_Include extends Text_Wiki_Render {    
    function token()
    {
        return '';
    }
}
?>