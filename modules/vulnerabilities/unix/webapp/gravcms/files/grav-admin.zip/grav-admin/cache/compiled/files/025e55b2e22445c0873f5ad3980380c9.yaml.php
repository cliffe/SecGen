<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/html/grav-admin/user/plugins/admin/languages/bn.yaml',
    'modified' => 1616003172,
    'data' => [
        'PLUGIN_ADMIN' => [
            'LOGIN_BTN' => 'লগ ইন',
            'LOGIN_BTN_FORGOT' => 'ভুলে গেছি'
        ]
    ]
];
