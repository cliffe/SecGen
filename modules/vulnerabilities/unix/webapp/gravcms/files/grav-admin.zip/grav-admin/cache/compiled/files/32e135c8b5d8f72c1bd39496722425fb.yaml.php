<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/html/grav-admin/user/plugins/flex-objects/blueprints/flex-objects/user-groups.yaml',
    'modified' => 1616003172,
    'data' => [
        'title' => 'User Groups (Admin)',
        'description' => 'Manage your User Groups in the new Flex admin.',
        'type' => 'flex-objects',
        'extends@' => [
            'type' => 'user-groups',
            'context' => 'blueprints://flex'
        ]
    ]
];
